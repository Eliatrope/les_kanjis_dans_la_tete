  </body>
  <script type="text/javascript" src="assets/js/handwriting.canvas.js"></script>
  <script src="assets/js/main.js" type="text/javascript"></script>
</html>
