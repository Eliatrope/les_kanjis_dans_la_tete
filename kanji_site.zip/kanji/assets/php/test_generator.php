<?php

?>
<section>
  <form action="genkouyoushi.php" method="POST">
    <label>de </label><input type="text" name="から" value="<?php if(isset($_POST['start_test'])){ echo $kara;}else{echo "1";}?>"/>
    <label>jusqu'à </label><input type="text" name="まで" value="<?php if(isset($_POST['start_test'])){ echo $made;}else{echo "50";}?>"/>
    <input type="submit" value="start_test" name="start_test"/>
  </form>
  <?php
    if(isset($_POST['start_test'])){
  ?>
  <div style="width:98%;height:100%;margin:auto">
  <?php
    while($q!=0){
  ?>
    <div style="width:10%;height:102px;float:left;border:1px solid black;box-sizing:border-box;position:relative;">
      <div style="position:absolute;width:69px;height:69px;border:1px solid black;left:-1px;overflow:hidden;top:18px;opacity:0.15;">
        <hr style="position:absolute;width:100%;border:1px dashed black;margin:0;height:0;top:49%;"/>
        <hr style="position:absolute;width:100%;border:1px dashed black;margin:0;height:0;top:49%;transform:rotate(90deg);"/>
      </div>
      <span style="position:absolute;top:5px;left:5px;font-size:7px;"><?php echo $kanji_choice['kanji']['id_kdlt'][$gen[$q-1]];?></span>
      <p style="text-align:center;font-size:25px;margin:10px 0 10px 0;opacity:0;"><?php echo $kanji_choice['kanji']['kanji'][$gen[$q-1]];?></p>
      <p style="text-align:center;font-size:9px;margin:47px 0 0 0;white-space:nowrap;"><?php echo $kanji_choice['kanji']['sens_kdlt'][$gen[$q-1]];?></p>
      <?php
        if(is_int($q/10)){
      ?>
        <br /><div style="clear:fixed;"></div>
      <?php
        }
      ?>
    </div>
  <?php
      $q-=1;
      $i++;
    }
  ?>
  </div>
  <?php
    }//end isset start_test
  ?>
</section>
