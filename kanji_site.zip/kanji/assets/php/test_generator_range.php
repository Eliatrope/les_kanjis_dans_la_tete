<?php ?>
<section>
  <form action="" method="POST">
    <label>nombre de kanji à tester (range) ; laisser vide si vous souhaitez tester l'intégralité de la range entre de et jusqu'à <br />range</label>

    <input id="input_range" type="number" name="range" placeholder="953" value="<?php if(isset($_POST['range'])){ echo $_POST['range'];}else{echo "";}?>"/>
    <br />
    <br />
    <label>de </label><input id="kara" type="text" name="から" value="<?php if(isset($_POST['start_test_range'])){ echo $kara;}else{echo "1";}?>"/>
    <label>jusqu'à </label><input id="made" type="text" name="まで" value="<?php if(isset($_POST['start_test_range'])){ echo $made;}else{echo "50";}?>"/>
    <input type="submit" value="start_test_range" name="start_test_range"/>
  </form>
  <?php
    if(isset($_POST['start_test_range'])){
      if($_POST["range"] == 0){
        $range = $made-$kara+1;
        //echo $range;
      }else{
        $range = $_POST["range"];
      }
        if($range > $made || $range <= 0 || $range > $made-$kara+1){
          echo "la range doit être un nombre entier et la range ne peut pas être inférieure ou égale à 0. En outre, la range ne peut pas être supérieure à la variable jusqu'à, ni à la différence entre les variables jusqu'à et depuis + 1, merci de modifier l'une ou l'autre des valeurs en conséquence";
        /*}elseif($range == null || $range <= 0){
          $range = $made-$kara+1;*/
        }else{

          //$sql = "SELECT * FROM kanji WHERE id_kdlt BETWEEN '".$kara."' AND ".$made."'";
  ?>
  <div style="width:98%;height:100%;margin:auto">
  <?php
    while($range!=0){
  ?>
    <div id="container_range_kanji_test" style="width:10%;height:108px;float:left;border:1px solid black;box-sizing:border-box;position:relative;">
      <span style="position:absolute;top:5px;left:5px;font-size:10px;"><?php echo $kanji_choice['kanji']['id_kdlt'][$gen[$q-1]];?></span>
      <p style="text-align:center;font-size:25px;margin:10px 0 10px 0;opacity:100;"><span><?php echo $kanji_choice['kanji']['kanji'][$gen[$q-1]];?></span> | <span style="font-family:'KanjiStrokeOrders';font-size:25px;"><?php echo $kanji_choice['kanji']['kanji'][$gen[$q-1]];?></span></p>
      <p style="text-align:center;font-size:12px;margin:10px 0 10px 0;white-space:nowrap;opacity:0;"><?php echo $kanji_choice['kanji']['sens_kdlt'][$gen[$q-1]];?></p>
      <input class="input_check_kanji_test" id="input_check_<?php echo $i;?>" type="text" name="<?php echo $kanji_choice['kanji']['sens_kdlt'][$gen[$q-1]];?>"/>
      <?php
        if(is_int($q/10)){
      ?>
        <br /><div style="clear:fixed;"></div>
      <?php
        }
      ?>
    </div>
  <?php
      $q-=1;
      $range-=1;
      $i++;
    }
  }//end if range > made
  ?>
  </div>
  <?php
}else{

}//end isset start_test_range
  ?>
</section>
