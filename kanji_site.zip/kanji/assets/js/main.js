//Event canvas handwritingX
var can1 = new handwriting.Canvas(document.getElementById("can"));

//Set callback function
    can1.setCallBack(function(data, err) {
        if(err) throw err;
        else console.log(data);
    });

    //Set line width shown on the canvas element (default: 3)
    can1.setLineWidth(5);

    //Set options
    can1.setOptions(
        {
            width: 800,
            height: 800,
            language: "ja",
            numOfWords: 1,
            numOfReturn: 3
        }
    );

    //recognize captured trace
    //can1.recognize();

    //Clear canvas, captured trace, and stored steps
    can1.erase();

   //turn on both functionalities
   can1.set_Undo_Redo(true, true);

   can1.undo();
   //set canvas and stored trace to the last state (stroke)

   can1.redo();
   //if there are undo records, return to the state of the next stored step

   //can1.recognize(trace, options, callback);

//event on change (correction automatique de la value de l'input (insensible à la casse mais pas aux accents/caractères spéciaux))
var j = 0;
var range = document.querySelector('#input_range').value;
console.log(range);
if(range == ""){
  var range = document.querySelector('#made').value-document.querySelector('#kara').value+1;
}

while (j < range){
  var checkInput = document.querySelector('#input_check_'+j);
  if(checkInput){
      checkInput.addEventListener('change',function(){
        if (this.name.toLowerCase() == this.value.toLowerCase()){
          this.style.outline = "solid green 2px";
        }else{
          this.style.outline = "solid red 2px";
        }
      });
    }
    j +=1;
}

//Event on click
var clickStateT = 0;
var clickStateF = 0;
var i = 0;
while (i < 2500){

  //var clickState = 0;
  var btnFalse = document.querySelector('#false_kanji_'+i);
  var btnTrue = document.querySelector('#true_kanji_'+i);

  if(btnFalse){
    btnFalse.addEventListener('click', function(){
        if (clickStateF == 0) {
          // code snippet 1
          //this.style.color = 'black';
          this.style.opacity = '1';
          clickStateF = 1;
        } else {
          // code snippet 2
          //this.style.color = 'white';
          this.style.opacity = '0';
          clickStateF = 0;
        }
    });
  }

  if(btnTrue){
    btnTrue.addEventListener('click', function(){
      if (clickStateT == 0) {
        // code snippet 1
        //this.style.color = 'black';
        this.style.opacity = '1';
        clickStateT = 1;
      } else {
        // code snippet 2
        //this.style.color = 'white';
        this.style.opacity = '0';
        clickStateT = 0;
      }
    });
  }
  i +=1;
}
var PopUpCanvas = document.querySelector('#pop_up_canvas');
var CanvasHandW = document.querySelector('#container_canvas');
var ByeCanvas = document.querySelector('#bye_canvas');
if(PopUpCanvas){
  PopUpCanvas.addEventListener('click', function(){
    CanvasHandW.style.display = 'block';
    PopUpCanvas.style.display = 'none';
  });
}
if(ByeCanvas){
  ByeCanvas.addEventListener('click', function(){
    CanvasHandW.style.display = 'none';
    PopUpCanvas.style.display = 'block';
  });
}
