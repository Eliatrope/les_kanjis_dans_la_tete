<?php require_once("header.php");?>
<section id="section_intro" style="margin:0 10px 0 10px;">
  <i>Mise à jour le 12/07/2023</i><br />
  <h2>Introduction</h2>
  <p>
    Avant tout, ce site web a pour vocation de permettre de procéder à des révisions et tests de kanji, par le biais d'exercices.<br /><br />
    Les identifiants et mots-clés associés aux kanji sont exclusivement issus de l'ouvrage <span style="text-decoration:underline;">Les Kanjis dans la tête</span> d'Yves MANIETTE, édition 2019 (ISBN 9782951255739).<br />
    Pour certains mots-clés homonymes, une précision entre parenthèses est donnée. Par exemple, le kanji n°191 胴 est originellement "Tronc", dans l'ouvrage. Pour éviter la confusion avec le kanji n°1803 幹 "Tronc d'arbre", le mot-clé du kanji n°191 a été transformé en "Tronc (du corps)". Cette précision a son importance pour certains exercices qui nécessitent d'indiquer, précisément justement, le mot-clé de rattachement. <br /><br />
    Il est possible, pour un étudiant n'utilisant pas l'ouvrage de Maniette, d'utiliser ces outils, sans garantie toutefois sur l'efficacité.<br /><br />
    Pour toute information sur l'ouvrage en lui-même, l'utilisateur est invité à visiter le site de l'auteur, à cette adresse : <a href="https://www.maniette.fr">maniette.fr</a><br /><br />
    Le site est en perpétuel développement, des modifications sont apportées de temps à autre, de nouveaux exercices peuvent aussi être implémentés. Cependant, certaines fonctionnalités, prévues originellement, ont pu être avortées faute de temps, d'utilité ou de technicité, et ne sont, de fait, pas fonctionnelles. Elles ne gênent cela dit en rien l'utilisation du site.<br /><br />
    Les kanjis proposés dans les exercices sont tous plus ou moins d'usage courant, et font, pour la plupart, partie de la liste des jōyō kanji e.g. 刃 ainsi que des jinmeiyō kanji e.g. 寅. Résidera aussi peut-être quelques hyōgai kanji e.g. 爿, pas forcément d'usage courant, mais qui ont leur utilité, toujours au regard du manuel de Maniette.<br />
    La "kanji chizu", source wikipedia, à découvrir en cliquant <a href="https://upload.wikimedia.org/wikipedia/commons/1/11/3002_Kanji.svg">ici</a>
    <br /><br />
    Tous les tests sont générés aléatoirement.<br /><br />
    Aujourd'hui, les tests proposés sur ce site web permettent uniquement de s'entraîner sur l'aspect écrit dudit kanji, ainsi que sur la connaissance de sa signifation, ou tout du moins de l'idée principale qui en découle, en français.<br />
    Les tests ne permettent pas de s'exercer à la lecture des kanjis.<br /><br />
    Pour tout signalement de coquille, de bug, ou toute suggestion, merci de passer par la page <a href="contact.php">contact</a>. <br /><br />
    Merci
  </p>
  <h2>Test de kanji par identifiant (de --> jusqu'à)</h2>
  <p>
    L'idée originelle de ce test était de permettre de vérifier la connaissance du kanji en deux temps. <br />
    Dans un premier temps, le test propose de dessiner le kanji correspondant au mot-clé donné. En cliquant au centre de la case de l'étape 1, un kanji apparaît, ce qui permet de comparer les deux kanjis. Puis, avec les boutons はい et いいえ, on répondait à la question posée. <br />
    Si la réponse est "Oui", on passe au kanji suivant ; si on doute un peu, rien n'empêche de vérifier la vérité à l'étape 2.<br />
    Si la réponse est "Non", on passe à l'étape 2, pour l'ultime vérification. <br /><br />
    En somme, l'étape 1 montre aléatoirement un kanji de la range, qui peut, ou non, correspondre à la vérité. L'étape 2 quant à elle, donnera toujours la bonne réponse.<br /><br />
    Etait évoqué un peu plus haut des fonctionnalités imaginées mais ne fonctionnant pas en l'état. Ce test en comporte plusieurs, notamment les boutons はい et いいえ.
  </p>
  <h2>Mise en forme Genkō yōshi</h2>
  <p>
    Générer le test type Genkō yōshi (mode tableau) redirigera vers une page dédiée, comportant des cases formant un tableau type Genkō yōshi standard. <br /><br />
    Chaque case est composée de l'identifiant, dans le coin supérieur gauche, relatif au kanji à écrire, d'un carré central scindé au milieu horizontalement et verticalement, ainsi que du mot-clé, centré en bas, relatif au kanji à écrire.<br /><br />
    En visualisant cette page sur un écran (screenview), les cases sembleront désordonnées. Toutefois, l'utilisateur s'apercevra qu'en impression (printview), le rendu est correct. Il est conseillé de laisser les paramètres d'impression par défaut, en conservant notamment les marges, les en-têtes et pieds de page.<br />
    Une page A4 en format portrait est censée contenir 100 cases sur le recto, et 100 autres sur le verso, soit 200 cases par page recto-verso.
  </p>
  <h2>Test de kanji par identifiant (range à définir)</h2>
  <p>
    Ce test propose de vérifier l'association entre le kanji proposé, et le mot-clé auquel il est rattaché.<br /><br />
    Ce test est relativement sensible à la casse. La vérification est effectuée automatiquement, via l'input : si l'association est correcte, le contour de l'input passe en vert. En revanche, si elle est fausse, celui-ci passe en rouge.
  </p>

</section>
<?php require_once("footer.php");?>
