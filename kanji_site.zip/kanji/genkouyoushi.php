<?php require_once("connex.php");?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  </head>
<?php
  if(isset($_POST['start']) || isset($_POST['start_test']) || isset($_POST['start_test_range'])){
    $kara = $_POST['から'];
    $made = $_POST['まで'];
    $i = 0;
    $kanji_choice = array();
    if($kara>=$made || $kara==0 || $made==0 || $made>2223){
      echo "Merci de saisir un nombre différent à chaque fois, en respectant la norme (nombre de gauche plus petit que le nombre de droite) ; en outre, le chiffre 0 n'est pas autorisé. Le nombre de droite ne peut également pas excéder 2223";
    }else{
      foreach($dbh->query('SELECT * from kanji WHERE id_kdlt BETWEEN '.$kara.' AND '.$made.'') as $row) {
        $kanji_choice['kanji']['id_kdlt'][$row['id_kdlt']] = $row['id_kdlt'];
        $kanji_choice['kanji']['sens_kdlt'][$row['id_kdlt']] = $row['sens_kdlt'];
        $kanji_choice['kanji']['kanji'][$row['id_kdlt']] = $row['kanji'];
        $i++;
      }
      $quantity_kanji=$i;
      $q=$i;
      $i=0;
      //var_dump($kanji_choice);
      //var_dump($kanji_choice['kanji']['id_kdlt']);

      function randomGen($kara, $made, $quantity) {
          $numbers = range($kara, $made);
          shuffle($numbers);
          //return array_slice($numbers, 0, $quantity);
          return $numbers;
      }

      $gen=randomGen($kara,$made,$made-$kara+1);
      $falsegen=randomGen($kara,$made,$made-$kara+1);
      /*while($q!=0){
        echo $kanji_choice['kanji']['kanji'][$gen[$q-1]]." ";
        $q-=1;
      }*/
    }
  }else{
    echo "Rien à voir ici pour le moment, merci de retourner à <a href='index.php'>l'accueil</a>";
  }
?>

<?php
  if(isset($_POST['start_test'])){
?>
<div style="width:98%;height:100%;margin:auto">
<?php
  if(isset($q)){
    while($q!=0){

?>
  <div style="width:10%;height:102px;float:left;border:1px solid black;box-sizing:border-box;position:relative;overflow:hidden;">
    <div style="position:absolute;width:69px;height:69px;border:1px solid black;left:-1px;overflow:hidden;top:18px;opacity:0.15;">
      <hr style="position:absolute;width:100%;border:1px dashed black;margin:0;height:0;top:49%;"/>
      <hr style="position:absolute;width:100%;border:1px dashed black;margin:0;height:0;top:49%;transform:rotate(90deg);"/>
    </div>
    <span style="position:absolute;top:5px;left:5px;font-size:7px;"><?php echo $kanji_choice['kanji']['id_kdlt'][$gen[$q-1]];?></span>
    <!--<p style="text-align:center;font-size:25px;margin:10px 0 10px 0;opacity:0;"><?php //echo $kanji_choice['kanji']['kanji'][$gen[$q-1]];?></p>-->
    <p style="text-align:center;font-size:9px;margin:90px 0 0 0;white-space:nowrap;"><?php echo $kanji_choice['kanji']['sens_kdlt'][$gen[$q-1]];?></p>
    <?php
      if(is_int($q/10)){
    ?>
      <div style="clear:fixed;"></div>
    <?php
      }
    ?>
  </div>
<?php
    $q-=1;
    $i++;
  }//end while
  }//end isset $q
?>
</div>
<?php
  }//end isset start_test
?>
</html>
