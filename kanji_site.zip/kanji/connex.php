<?php
  $user = "root";
  $pass = "root";
  try {
      $dbh = new PDO('mysql:host=localhost;dbname=kanji;charset=utf8', $user, $pass);
      /*foreach($dbh->query('SELECT * from kanji') as $row) {
          //print_r($row);
      }*/
      //$dbh = null;
  } catch (PDOException $e) {
      print "Error!: " . $e->getMessage() . "<br/>";
      die();
  }
  //update
  /*$count = $dbh->exec("UPDATE kanji SET traduction = 'boîte mesure' WHERE id  = 41");
  echo $count;*/
?>
