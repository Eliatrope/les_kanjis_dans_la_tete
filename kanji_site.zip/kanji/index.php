<?php
  require_once("header.php");
?>
    <div class="button_come_on_canvas" id="pop_up_canvas">
      <p>書</p>
    </div>
    <h2>Test de kanji par identifiant (de --> jusqu'à)</h2>
    <?php
      if(isset($_POST['start']) || isset($_POST['start_test']) || isset($_POST['start_test_range'])){
        $kara = $_POST['から'];
        $made = $_POST['まで'];
        $i = 0;
        $kanji_choice = array();
        if($kara>=$made || $kara==0 || $made==0 || $made>2223){
          echo "Merci de saisir un nombre différent à chaque fois, en respectant la norme (nombre de gauche plus petit que le nombre de droite) ; en outre, le chiffre 0 n'est pas autorisé. Le nombre de droite ne peut également pas excéder 2223";
        }else{
          foreach($dbh->query('SELECT * from kanji WHERE id_kdlt BETWEEN '.$kara.' AND '.$made.'') as $row) {
            $kanji_choice['kanji']['id_kdlt'][$row['id_kdlt']] = $row['id_kdlt'];
            $kanji_choice['kanji']['sens_kdlt'][$row['id_kdlt']] = $row['sens_kdlt'];
            $kanji_choice['kanji']['kanji'][$row['id_kdlt']] = $row['kanji'];
            $i++;
          }
          $quantity_kanji=$i;
          $q=$i;
          $i=0;
          //var_dump($kanji_choice);
          //var_dump($kanji_choice['kanji']['id_kdlt']);

          function randomGen($kara, $made, $quantity) {
              $numbers = range($kara, $made);
              shuffle($numbers);
              //return array_slice($numbers, 0, $quantity);
              return $numbers;
          }

          $gen=randomGen($kara,$made,$made-$kara+1);
          $falsegen=randomGen($kara,$made,$made-$kara+1);
          /*while($q!=0){
            echo $kanji_choice['kanji']['kanji'][$gen[$q-1]]." ";
            $q-=1;
          }*/
        }
      }
    ?>
    <form action="" method="POST">
      <label>de </label><input type="text" name="から" value="<?php if(isset($_POST['start'])){ echo $kara;}else{echo "1";}?>"/>
      <label>jusqu'à </label><input type="text" name="まで" value="<?php if(isset($_POST['start'])){ echo $made;}else{echo "50";}?>"/>
      <input type="submit" value="start" name="start"/>
    </form>
    <section class="main_section">
      <div class="container_canvas" id="container_canvas">
        <canvas id="can" width="400" height="400" style="border: 2px solid; cursor: crosshair; background-color:white;"></canvas>
        <div class="clear"></div>
        <div class="container_button_canvas">
          <div class="button_canvas" onclick="can1.undo();">UNDO</div>
          <div class="button_canvas" onclick="can1.redo();">REDO</div>
          <div class="button_canvas" onclick="can1.erase();">ERASE</div>
        </div>
        <div class="bye_canvas" id="bye_canvas">X</div>
      </div>
    <?php
    if(isset($_POST['start']) && isset($q)){
      while($q!=0){
    ?>
      <div class="wrap_container">
        <h2>Etape 1) Dessine le kanji</h2>
        <div class="container_yall_kanji">
          <p class="container_false_kanji button-elem" id="false_kanji_<?php echo $i;?>"><?php echo $kanji_choice['kanji']['kanji'][$falsegen[$q-1]];?></p>
          <p class="container_answer"><?php echo $kanji_choice['kanji']['sens_kdlt'][$gen[$q-1]];?></p>
          <div class="container_batch_answer">
            <h3>Le couple ci-dessus correspond-il ?</h3>
            <div class="wrap_button">
              <button>はい</button>
              <button>いいえ</button>
            </div>
          </div>
        </div>
      </div>
      <div class="wrap_container">
        <span class="count_kanji"><?php echo $i+1;?>/<?php echo $quantity_kanji?><br /> <?php echo $kanji_choice['kanji']['id_kdlt'][$gen[$q-1]] ?></span>
        <h2>Etape 2) Vérifie le couple kanji/kanji dessiné</h2>
        <div class="container_yall_kanji">
          <p class="container_true_kanji" id="true_kanji_<?php echo $i;?>"><?php echo $kanji_choice['kanji']['kanji'][$gen[$q-1]];?></p>
          <p class="container_answer"><?php echo $kanji_choice['kanji']['sens_kdlt'][$gen[$q-1]];?></p>
          <div class="container_batch_answer">
            <h3>Le couple correspond-il ?</h3>
            <div class="wrap_button">
              <button>はい</button>
              <button>いいえ</button>
            </div>
          </div>
        </div>
      </div>
      <hr style="border:1px dashed black"/>
    <?php
      $q-=1;
      $i++;
    }
    $i=0;
  }

    ?>
    </section>
    <h2>Générer un test type Genkō yōshi (mode tableau)</h2>
    <?php
      require_once('assets/php/test_generator.php');
    ?>
    <div class="clear"></div>
    <h2>Test de kanji par identifiant (range à définir (facultatif) + identifiants "de" "jusqu'à" des kanji à tester dans cette range)</h2>
    <?php
      require_once('assets/php/test_generator_range.php');
      require_once("footer.php");
    ?>
