<ul>
  <li><a href="intro.php">Présentation</a></li>
  <li><a href="contact.php">Contact</a></li>
</ul>
