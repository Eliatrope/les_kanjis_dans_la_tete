<?php require_once("connex.php")?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Hachi+Maru+Pop&display=swap" rel="stylesheet">
  </head>
  <body>
    <h1 style="text-decoration:underline;text-align:center;font-family:Arial"><a href="index.php">Les Kanjis dans la tête</a></h1>
    <?php require_once("menu.php");?>
